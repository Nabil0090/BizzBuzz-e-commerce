export default function Admin() {
  return <div>Hello Admin</div>;
}
