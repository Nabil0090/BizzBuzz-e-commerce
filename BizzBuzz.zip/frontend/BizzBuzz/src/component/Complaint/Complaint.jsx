export default function Complaint() {
    return <div>No complaint yet</div>;
  }