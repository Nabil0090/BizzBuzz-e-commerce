export default function Cart() {
  return <div>Meherab</div>;
}
